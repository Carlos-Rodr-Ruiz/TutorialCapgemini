export class SortPage{
    property: String;
    direction: String;
}